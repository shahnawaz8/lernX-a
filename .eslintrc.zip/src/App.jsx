import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import { CiMenuFries } from "react-icons/ci";

import "./App.css";
import HomePage from "./components/Home";

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="flex h-screen ">
      {/* Sidebar for desktop */}
      <aside
        className={`hidden sm:block w-55 p-2 bg-white border-r overflow-y-auto transition-transform ease-in-out duration-300 transform ${
          isSidebarOpen ? "translate-x-0" : "-translate"
        }`}
      >
        <div>
          <h1 className="text-lg font-semibold">Sidebar</h1>
        </div>
        <nav>
          <ul className="text-left">
            <li>
              <a
                href="#"
                className="block py-2 text-gray-600 hover:bg-gray-200 rounded"
              >
                Home
              </a>
            </li>
            <li>
              <a
                href="#"
                className="block py-2  text-gray-600 hover:bg-gray-200 rounded"
              >
                My Profile
              </a>
            </li>
            <li>
              <a
                href="#"
                className="block py-2  text-gray-600 hover:bg-gray-200 rounded"
              >
                Menu
              </a>
            </li>
            <li>
              <a
                href="#"
                className="block py-2 text-gray-600 hover:bg-gray-200 rounded"
              >
                Explore
              </a>
            </li>
          </ul>
        </nav>
      </aside>

      {/* Menu icon for mobile */}
      <div className="sm:hidden fixed inset-0 z-50" onClick={toggleSidebar}>
        <button className="fixed top-4 left-4" onClick={toggleSidebar}>
          <CiMenuFries style={{ fontSize: 25 }} />
        </button>

        <div
          className={`fixed inset-y-0 left-0 w-64 bg-white border-r overflow-y-auto ease-in-out duration-300 transform ${
            isSidebarOpen ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <div className="py-4 px-3">
            <h1 className="text-lg font-semibold">Sidebar</h1>
          </div>
          <nav className="mt-2">
            <ul className="space-y-1">
              <li>
                <a
                  href="#"
                  className="block py-2 px-3 text-gray-600 hover:bg-gray-200 rounded"
                >
                  Home
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="block py-2 px-3 text-gray-600 hover:bg-gray-200 rounded"
                >
                  My Profile
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="block py-2 px-3 text-gray-600 hover:bg-gray-200 rounded"
                >
                  Menu
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="block py-2 px-3 text-gray-600 hover:bg-gray-200 rounded"
                >
                  Explore
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>

      <main className="flex-1 p-4 overflow-y-auto">
        <HomePage />
      </main>
    </div>
  );
}

export default App;
